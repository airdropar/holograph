# 🚀 Quick Start - Deploy in 5 Minutes

The fastest way to get your Blueprint Video Theme live on the web.

## ⚡ Super Quick Deploy (Using Vercel)

**Prerequisites**: Node.js installed on your computer

### Steps:

1. **Open Terminal** in the project folder

2. **Run one command**:
   ```bash
   npx vercel --prod
   ```

3. **Follow the prompts**:
   - Login with GitHub (first time only)
   - Project name: `blueprint-video-theme`
   - Directory: Press Enter (use current)
   - Override settings: `N` (no)

4. **Done!** 🎉

Your site is now live at: `https://your-project.vercel.app`

- **Main Site**: `https://your-project.vercel.app/`
- **Admin Panel**: `https://your-project.vercel.app/admin.html`

---

## 🎬 What You Get

✅ **Public Website** with video backgrounds and smooth animations
✅ **Admin Panel** to manage layouts and content  
✅ **REST API** for dynamic content
✅ **Free Hosting** with automatic HTTPS
✅ **Global CDN** for fast loading worldwide

---

## 📝 Next Steps After Deployment

### 1. Access Your Admin Panel

Go to: `https://your-project.vercel.app/admin.html`

### 2. Create Your First Layout

- Click "New Layout"
- Choose a type (Hero, Content, Footer, etc.)
- Enter a title and description
- Add a video URL (use free videos from Pexels or Pixabay)
- Click "Create"

### 3. View Your Site

Go to: `https://your-project.vercel.app/`

Your new layout will appear on the homepage!

---

## 🎥 Where to Get Free Videos

Use these sources for video URLs:

1. **Pexels Videos**: https://www.pexels.com/videos/
   - Download any video
   - Upload to Cloudinary (free account)
   - Use the Cloudinary URL

2. **Pixabay Videos**: https://pixabay.com/videos/
   - Same process as Pexels

3. **Google's Sample Videos** (for testing):
   ```
   https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4
   https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4
   ```

---

## 🔧 Common Issues

### "Command not found: npx"

**Solution**: Install Node.js from https://nodejs.org

### Videos not playing

**Solution**: Make sure the video URL is:
- Publicly accessible
- Direct video file link (ends in .mp4, .webm, etc.)
- Not behind authentication

### API not working

**Solution**: Vercel automatically sets up the API. Wait 1-2 minutes after deployment for it to fully activate.

---

## 🎨 Customize Your Site

### Change Colors

Edit the CSS variables in `index.html`:

```css
:root {
  --shade-9: #171717;  /* Text color */
  --accent: #3B82F6;   /* Accent color */
  /* Change these to your brand colors */
}
```

### Change Fonts

Update the Google Fonts import:

```html
<link href="https://fonts.googleapis.com/css2?family=YOUR_FONT&display=swap" rel="stylesheet">
```

### Add Your Logo

Replace the text logo in the navigation:

```html
<a href="#" className="nav-brand">YOUR LOGO</a>
```

---

## 📱 Share Your Site

Once deployed, share these URLs:

- **Main Site**: For visitors
- **Admin Panel**: For content editors (keep this private!)

---

## 💡 Pro Tips

1. **Custom Domain**: In Vercel dashboard, go to Settings > Domains to add your own domain

2. **Analytics**: Add Google Analytics to track visitors

3. **Database**: For production, add MongoDB or PostgreSQL (see DEPLOYMENT.md)

4. **Video Hosting**: Use Cloudinary for better video performance

---

## 🆘 Need Help?

- Read `DEPLOYMENT.md` for detailed instructions
- Check `README.md` for full documentation
- Review `IMPLEMENTATION.md` for technical details

---

**That's it!** Your video-powered website is now live. 🎉

Start creating layouts in the admin panel and watch your site come to life!
