# 🚀 Deployment Guide - Blueprint Video Theme

This guide will help you deploy the Blueprint Video Theme to the web for free.

## 📋 What You'll Deploy

- **Frontend**: React-based HTML files (index.html, admin.html)
- **Backend API**: Serverless functions via Vercel
- **Database**: In-memory storage (can upgrade to MongoDB/PostgreSQL)

---

## 🌐 Option 1: Deploy to Vercel (Recommended)

**Why Vercel?** Free hosting, automatic HTTPS, serverless functions, global CDN.

### Prerequisites
- GitHub account
- Git installed on your computer

### Step-by-Step Instructions

#### 1. Create a GitHub Repository

```bash
# In your terminal, navigate to the project folder
cd path/to/blueprint-video-theme

# Initialize git
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit - Blueprint Video Theme"

# Create a new repository on GitHub (https://github.com/new)
# Then link and push:
git remote add origin https://github.com/YOUR_USERNAME/blueprint-video-theme.git
git branch -M main
git push -u origin main
```

#### 2. Deploy to Vercel

**Option A: Using Vercel Website**

1. Go to [vercel.com](https://vercel.com)
2. Click "Sign Up" and use GitHub
3. Click "New Project"
4. Import your GitHub repository
5. Vercel will auto-detect settings
6. Click "Deploy"
7. Done! Your site is live at `your-project.vercel.app`

**Option B: Using Vercel CLI**

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel

# Follow the prompts:
# - Link to existing project? No
# - Project name? blueprint-video-theme
# - Directory? ./
# - Override settings? No

# Your site is now live!
```

#### 3. Access Your Site

- **Main Site**: `https://your-project.vercel.app/`
- **Admin Panel**: `https://your-project.vercel.app/admin.html`
- **API**: `https://your-project.vercel.app/api/layouts`

---

## 🔥 Option 2: Deploy to Netlify

**Why Netlify?** Easy drag-and-drop, form handling, free SSL.

### Step-by-Step Instructions

#### 1. Prepare for Netlify

Create a `netlify.toml` file in your project root:

```toml
[build]
  publish = "."

[[redirects]]
  from = "/api/*"
  to = "/.netlify/functions/:splat"
  status = 200

[functions]
  directory = "netlify/functions"
```

Create the functions directory:

```bash
mkdir -p netlify/functions
```

Move your API to a Netlify function:

```javascript
// netlify/functions/api.js
const express = require('express');
const serverless = require('serverless-http');

const app = express();
app.use(express.json());

// ... (copy your API code from api/server.js)

module.exports.handler = serverless(app);
```

#### 2. Deploy to Netlify

**Option A: Drag and Drop**

1. Go to [netlify.com](https://netlify.com)
2. Sign up with GitHub
3. Drag your project folder to the deploy zone
4. Done! Site is live

**Option B: GitHub Integration**

1. Push to GitHub (see Vercel steps above)
2. Go to Netlify dashboard
3. Click "New site from Git"
4. Connect to GitHub
5. Select your repository
6. Click "Deploy site"

#### 3. Access Your Site

- **Main Site**: `https://your-site.netlify.app/`
- **Admin Panel**: `https://your-site.netlify.app/admin.html`

---

## 💨 Option 3: Deploy to GitHub Pages (Static Only)

**Note**: GitHub Pages doesn't support serverless functions, so this is frontend-only.

### Step-by-Step Instructions

#### 1. Update API URLs

In both `index.html` and `admin.html`, change:

```javascript
const API_BASE_URL = 'https://your-vercel-api.vercel.app/api';
```

#### 2. Enable GitHub Pages

1. Push your code to GitHub
2. Go to repository Settings
3. Scroll to "Pages"
4. Source: Deploy from a branch
5. Branch: main, folder: / (root)
6. Click Save

#### 3. Access Your Site

- **Main Site**: `https://YOUR_USERNAME.github.io/blueprint-video-theme/`
- **Admin Panel**: `https://YOUR_USERNAME.github.io/blueprint-video-theme/admin.html`

---

## 🐳 Option 4: Deploy to Railway (Full Stack)

**Why Railway?** Supports full Node.js backend, PostgreSQL database.

### Step-by-Step Instructions

#### 1. Create railway.json

```json
{
  "build": {
    "builder": "NIXPACKS"
  },
  "deploy": {
    "startCommand": "npm start",
    "restartPolicyType": "ON_FAILURE"
  }
}
```

#### 2. Update package.json

Add a start script:

```json
{
  "scripts": {
    "start": "node backend/server.js"
  }
}
```

#### 3. Deploy to Railway

1. Go to [railway.app](https://railway.app)
2. Sign up with GitHub
3. Click "New Project"
4. Choose "Deploy from GitHub repo"
5. Select your repository
6. Railway auto-deploys

#### 4. Access Your Site

Railway will provide a URL like `your-project.up.railway.app`

---

## 🗄️ Adding a Database

### For Production Use

Replace in-memory storage with a real database:

#### Option A: MongoDB (Free with MongoDB Atlas)

1. Sign up at [mongodb.com/atlas](https://www.mongodb.com/atlas)
2. Create a free cluster
3. Get connection string
4. Install MongoDB driver:
   ```bash
   npm install mongodb
   ```
5. Update your API code to use MongoDB

#### Option B: PostgreSQL (Free with Vercel Postgres)

1. In Vercel dashboard, go to your project
2. Click "Storage" tab
3. Create a Postgres database
4. Install pg driver:
   ```bash
   npm install pg
   ```
5. Update your API code

---

## 🎥 Video Hosting Solutions

For production, you'll need proper video hosting:

### Free Options

1. **Cloudinary** (10GB free)
   - Sign up at [cloudinary.com](https://cloudinary.com)
   - Upload videos via dashboard
   - Use provided URLs in your layouts

2. **Bunny CDN** ($1/TB)
   - Very affordable
   - Fast global CDN
   - Video optimization

3. **Free Stock Videos**
   - [Pexels Videos](https://www.pexels.com/videos/)
   - [Pixabay Videos](https://pixabay.com/videos/)
   - [Coverr](https://coverr.co/)

### Usage in Your App

```javascript
// Example with Cloudinary URL
videoUrl: "https://res.cloudinary.com/YOUR_CLOUD/video/upload/v123456/sample.mp4"
```

---

## ✅ Post-Deployment Checklist

After deployment, verify:

- [ ] Main site loads correctly
- [ ] Admin panel is accessible
- [ ] API endpoints respond (check /api/health)
- [ ] Videos play properly
- [ ] Forms submit successfully
- [ ] Mobile responsiveness works
- [ ] HTTPS is enabled

---

## 🔧 Troubleshooting

### API Not Working

**Issue**: API calls fail with CORS errors

**Solution**: Update CORS settings in api/server.js:
```javascript
app.use(cors({
  origin: 'https://your-site.vercel.app'
}));
```

### Videos Not Playing

**Issue**: Videos show black screen

**Solutions**:
1. Check video URL is publicly accessible
2. Verify video format (MP4, WebM, OGG)
3. Try a different video source
4. Check browser console for errors

### Deployment Fails

**Issue**: Build errors on Vercel/Netlify

**Solutions**:
1. Check package.json is in root directory
2. Verify Node.js version (should be 18+)
3. Check build logs for specific errors
4. Ensure all dependencies are listed

---

## 📊 Monitoring Your Site

### Free Tools

1. **Vercel Analytics** - Built-in with Vercel
2. **Google Analytics** - Add tracking code to HTML
3. **Plausible** - Privacy-friendly analytics
4. **Uptime Robot** - Monitor site availability

### Add Google Analytics

Add to `<head>` in index.html and admin.html:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

---

## 🎨 Custom Domain (Optional)

### On Vercel

1. Go to project settings
2. Click "Domains"
3. Add your domain
4. Update DNS records as instructed
5. SSL auto-configured

### On Netlify

1. Go to site settings
2. Click "Domain management"
3. Add custom domain
4. Follow DNS instructions

---

## 🚀 Quick Deploy Commands

```bash
# Vercel (one command deploy)
npx vercel --prod

# Netlify (one command deploy)
npx netlify-cli deploy --prod

# Update deployment
git add .
git commit -m "Update"
git push
# Vercel/Netlify auto-deploys on push
```

---

## 📞 Support

If you encounter issues:

1. Check deployment logs in your hosting platform
2. Review browser console for errors
3. Test API endpoints directly
4. Verify environment variables
5. Check hosting platform status page

---

**Congratulations!** 🎉 Your Blueprint Video Theme is now live on the web!

Access it at your deployment URL and share it with the world.
