#!/bin/bash

# Blueprint Video Theme - Quick Setup Script
# This script helps you deploy your site quickly

echo "🎬 Blueprint Video Theme - Setup Wizard"
echo "========================================="
echo ""

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo "❌ Git is not installed. Please install git first."
    exit 1
fi

echo "Choose your deployment method:"
echo "1) Vercel (Recommended - Free, Serverless)"
echo "2) Netlify (Free, Easy drag-and-drop)"
echo "3) GitHub Pages (Free, Static only)"
echo "4) Manual setup"
echo ""
read -p "Enter your choice (1-4): " choice

case $choice in
    1)
        echo ""
        echo "🚀 Setting up for Vercel deployment..."
        echo ""
        
        # Check if vercel CLI is installed
        if ! command -v vercel &> /dev/null; then
            echo "Installing Vercel CLI..."
            npm install -g vercel
        fi
        
        echo ""
        echo "Initializing git repository..."
        git init
        git add .
        git commit -m "Initial commit - Blueprint Video Theme"
        
        echo ""
        echo "📦 Deploying to Vercel..."
        echo "Please follow the prompts to deploy your site."
        vercel
        
        echo ""
        echo "✅ Deployment complete!"
        echo "Your site should now be live. Check the URL above."
        ;;
        
    2)
        echo ""
        echo "🌐 Setting up for Netlify deployment..."
        echo ""
        
        # Check if netlify CLI is installed
        if ! command -v netlify &> /dev/null; then
            echo "Installing Netlify CLI..."
            npm install -g netlify-cli
        fi
        
        echo ""
        echo "Initializing git repository..."
        git init
        git add .
        git commit -m "Initial commit - Blueprint Video Theme"
        
        echo ""
        echo "📦 Deploying to Netlify..."
        netlify deploy --prod
        
        echo ""
        echo "✅ Deployment complete!"
        ;;
        
    3)
        echo ""
        echo "📄 Setting up for GitHub Pages..."
        echo ""
        
        read -p "Enter your GitHub username: " github_user
        read -p "Enter repository name (default: blueprint-video-theme): " repo_name
        repo_name=${repo_name:-blueprint-video-theme}
        
        echo ""
        echo "Initializing git repository..."
        git init
        git add .
        git commit -m "Initial commit - Blueprint Video Theme"
        
        echo ""
        echo "Create a new repository on GitHub:"
        echo "https://github.com/new"
        echo ""
        echo "Repository name: $repo_name"
        echo ""
        read -p "Press Enter when you've created the repository..."
        
        git remote add origin "https://github.com/$github_user/$repo_name.git"
        git branch -M main
        git push -u origin main
        
        echo ""
        echo "✅ Code pushed to GitHub!"
        echo "Now enable GitHub Pages:"
        echo "1. Go to: https://github.com/$github_user/$repo_name/settings/pages"
        echo "2. Set Source to: Deploy from a branch"
        echo "3. Select: main branch, / (root)"
        echo "4. Click Save"
        echo ""
        echo "Your site will be live at:"
        echo "https://$github_user.github.io/$repo_name/"
        ;;
        
    4)
        echo ""
        echo "📝 Manual Setup Instructions"
        echo "============================"
        echo ""
        echo "To deploy manually:"
        echo ""
        echo "1. Install dependencies:"
        echo "   npm install"
        echo ""
        echo "2. Choose a hosting platform:"
        echo "   - Vercel: https://vercel.com"
        echo "   - Netlify: https://netlify.com"
        echo "   - Railway: https://railway.app"
        echo ""
        echo "3. Follow the platform-specific instructions in DEPLOYMENT.md"
        echo ""
        echo "4. For video hosting, use:"
        echo "   - Cloudinary (free tier)"
        echo "   - Bunny CDN"
        echo "   - Free stock videos from Pexels/Pixabay"
        echo ""
        ;;
        
    *)
        echo "Invalid choice. Please run the script again and choose 1-4."
        exit 1
        ;;
esac

echo ""
echo "🎉 Setup complete!"
echo ""
echo "Next steps:"
echo "1. Visit your deployed site"
echo "2. Go to /admin.html to manage content"
echo "3. Create new layouts and add video URLs"
echo "4. Check DEPLOYMENT.md for advanced configuration"
echo ""
echo "Need help? Check the documentation files:"
echo "- README.md - General usage"
echo "- DEPLOYMENT.md - Deployment guide"
echo "- IMPLEMENTATION.md - Technical details"
echo ""
