// Vercel Serverless Function
const express = require('express');
const cors = require('cors');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// In-memory storage (in production, use a database like MongoDB or PostgreSQL)
let layouts = [
  {
    id: 1,
    type: 'hero',
    title: 'Hero Sections',
    description: '11 dynamic hero layouts with video backgrounds and smooth animations',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    thumbnailUrl: '',
    createdAt: new Date().toISOString()
  },
  {
    id: 2,
    type: 'content',
    title: 'Content Blocks',
    description: 'Flexible content sections with parallax video effects',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    thumbnailUrl: '',
    createdAt: new Date().toISOString()
  },
  {
    id: 3,
    type: 'footer',
    title: 'Footer Designs',
    description: 'Modern footer layouts with ambient video backgrounds',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    thumbnailUrl: '',
    createdAt: new Date().toISOString()
  },
  {
    id: 4,
    type: 'info',
    title: 'Info Sections',
    description: 'Information displays with cinematic video presentations',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    thumbnailUrl: '',
    createdAt: new Date().toISOString()
  },
  {
    id: 5,
    type: 'blog',
    title: 'Blog Layouts',
    description: 'Editorial-style blog sections with video headers',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4',
    thumbnailUrl: '',
    createdAt: new Date().toISOString()
  },
  {
    id: 6,
    type: 'modal',
    title: 'Modal Designs',
    description: 'Interactive modals with full-screen video capabilities',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4',
    thumbnailUrl: '',
    createdAt: new Date().toISOString()
  }
];

let nextLayoutId = layouts.length + 1;

// API Routes

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    message: 'API is running',
    timestamp: new Date().toISOString()
  });
});

// Get all layouts
app.get('/api/layouts', (req, res) => {
  const { type, limit } = req.query;
  let filteredLayouts = layouts;
  
  if (type) {
    filteredLayouts = layouts.filter(layout => layout.type === type);
  }
  
  if (limit) {
    filteredLayouts = filteredLayouts.slice(0, parseInt(limit));
  }
  
  res.json({
    success: true,
    data: filteredLayouts,
    total: filteredLayouts.length
  });
});

// Get single layout
app.get('/api/layouts/:id', (req, res) => {
  const layout = layouts.find(l => l.id === parseInt(req.params.id));
  
  if (!layout) {
    return res.status(404).json({
      success: false,
      message: 'Layout not found'
    });
  }
  
  res.json({
    success: true,
    data: layout
  });
});

// Create new layout
app.post('/api/layouts', (req, res) => {
  const { type, title, description, videoUrl, thumbnailUrl } = req.body;
  
  if (!type || !title || !videoUrl) {
    return res.status(400).json({
      success: false,
      message: 'Missing required fields: type, title, videoUrl'
    });
  }
  
  const newLayout = {
    id: nextLayoutId++,
    type,
    title,
    description: description || '',
    videoUrl,
    thumbnailUrl: thumbnailUrl || '',
    createdAt: new Date().toISOString()
  };
  
  layouts.push(newLayout);
  
  res.status(201).json({
    success: true,
    data: newLayout
  });
});

// Update layout
app.put('/api/layouts/:id', (req, res) => {
  const layoutIndex = layouts.findIndex(l => l.id === parseInt(req.params.id));
  
  if (layoutIndex === -1) {
    return res.status(404).json({
      success: false,
      message: 'Layout not found'
    });
  }
  
  const { type, title, description, videoUrl, thumbnailUrl } = req.body;
  
  layouts[layoutIndex] = {
    ...layouts[layoutIndex],
    ...(type && { type }),
    ...(title && { title }),
    ...(description && { description }),
    ...(videoUrl && { videoUrl }),
    ...(thumbnailUrl && { thumbnailUrl }),
    updatedAt: new Date().toISOString()
  };
  
  res.json({
    success: true,
    data: layouts[layoutIndex]
  });
});

// Delete layout
app.delete('/api/layouts/:id', (req, res) => {
  const layoutIndex = layouts.findIndex(l => l.id === parseInt(req.params.id));
  
  if (layoutIndex === -1) {
    return res.status(404).json({
      success: false,
      message: 'Layout not found'
    });
  }
  
  const deletedLayout = layouts.splice(layoutIndex, 1)[0];
  
  res.json({
    success: true,
    data: deletedLayout
  });
});

// Videos endpoint (simplified for serverless - use external storage in production)
app.get('/api/videos', (req, res) => {
  res.json({
    success: true,
    data: [],
    total: 0,
    message: 'For video uploads, please use a cloud storage service like Cloudinary or AWS S3'
  });
});

// Error handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    success: false,
    message: err.message || 'Internal server error'
  });
});

// Export for Vercel
module.exports = app;
